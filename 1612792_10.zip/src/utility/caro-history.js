class CaroHistory {
    constructor(){
        
    }
}

export default CaroHistory;