- Hiển vị trí đánh trong giao diện hiển thị danh sách nước đi: 2 điểm
- In đậm dòng đang chọn ở danh sách nước đi: 2 điểm
- Thêm chức năng cho phép hiển thị danh sách nước đi giảm dần hay tăng dần: 2 điểm
- Khi có người thắng, làm rõ những quân cờ nào tạo thành đường thắng: 2 điểm
- Đăng tải lên host thực tế: 2 điểm


link host:
https://dracuten1.github.io/caro2/